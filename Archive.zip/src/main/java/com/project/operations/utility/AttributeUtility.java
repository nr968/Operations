package com.project.operations.utility;

import org.springframework.stereotype.Component;
import org.xml.sax.Attributes;

@Component
public class AttributeUtility {

    private long id = 0L;
    private boolean isComplex = false;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isComplex() {
        return isComplex;
    }

    public void setComplex(boolean complex) {
        isComplex = complex;
    }

    public void checkAttributes(Attributes attributes){
        if(attributes.getLength()==2){
            id = Long.parseLong(attributes.getValue("id"));
            isComplex = Boolean.parseBoolean(attributes.getValue("complex"));
        }else if(attributes.getLength()==1){
            id = Long.parseLong(attributes.getValue("id"));
            isComplex = Boolean.parseBoolean(attributes.getValue("complex"));
        }
    }
}
